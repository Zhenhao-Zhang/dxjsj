import matplotlib
import requests
from bs4 import BeautifulSoup
import csv
import pandas as pd
import tkinter as tk
import numpy as np
import matplotlib.pyplot as plt
import sqlite3
import os
import tkinter as tk
from tkinter import Toplevel
import time

def flex():
    global lex
    lex = 0

def main():
    flex()
    load_window = tk.Tk()
    load_window.geometry("600x350")
    load_window.title("数据系统登陆界面")

    l = tk.Label(load_window, text="数据处理系统", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l.pack()
    l2 = tk.Label(load_window, text="开发：UPC章震豪", bg="blue", font=("NotoSansHans", 12), width=200, height=2)
    l2.pack()
    l3 = tk.Label(load_window, text="以下是功能列表", bg="red", font=("NotoSansHans", 12), width=200, height=2)
    l3.pack()

    mian_button1 = tk.Button(load_window, text="用户登录", font=("NotoSansHans", 12), width=20, height=1, command=load1)
    mian_button1.pack()
    mian_button2 = tk.Button(load_window, text="用户注册", font=("NotoSansHans", 12), width=20, height=1, command=load2)
    mian_button2.pack()
    mian_button3 = tk.Button(load_window, text="打开系统", font=("NotoSansHans", 12), width=20, height=1, command=mainmin)
    mian_button3.pack()
    mian_button4 = tk.Button(load_window, text="退出系统", font=("NotoSansHans", 12), width=20, height=1, command=exit)
    mian_button4.pack()


def fop():
    f = open("users.txt", "r+", encoding="utf-8")
    number_and_keys = []
    for line in f:
        line.strip()
        m = line.split()
        number_and_keys.append(m)
    return number_and_keys


def open1():
    global lex
    lex = 1


def create(l):
    f = open("users.txt", "r+", encoding="utf-8")
    l1 = l[0]
    l2 = l[1]
    t = "\n" + l1 + " " + l2
    f.write(t)
    f.flush()
    open1()


def message1():
    import tkinter as tk
    window = tk.Tk()
    window.geometry("600x350")
    window.title("错误提示")
    l = tk.Label(window, text="输入账号密码错误，请重新输入", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l.pack()


def message2():
    import tkinter as tk
    window = tk.Tk()
    window.geometry("600x350")
    window.title("错误提示")
    l = tk.Label(window, text="该账号密码已经被注册", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l.pack()


def load1():
    global l
    import tkinter as tk
    window = tk.Tk()
    window.geometry("600x350")
    window.title("请输入账号与密码")
    l4 = tk.Label(window, text="请输入账号", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l4.pack()
    entry1 = tk.Entry(window, width=20)
    entry1.pack()
    l5 = tk.Label(window, text="请输入密码", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l5.pack()
    entry2 = tk.Entry(window, width=20)
    entry2.pack()

    def change_state():
        global l
        number1 = entry1.get()
        number2 = entry2.get()
        l = []
        l.append(number1)
        l.append(number2)
        choose1()

    button = tk.Button(window, text='确认登录', command=change_state)
    button.pack()
    window.mainloop()


def load2():
    global l
    import tkinter as tk
    window = tk.Tk()
    window.geometry("600x350")
    window.title("请输入账号与密码")
    l4 = tk.Label(window, text="请输入账号", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l4.pack()
    entry1 = tk.Entry(window, width=20)
    entry1.pack()
    l5 = tk.Label(window, text="请输入密码", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l5.pack()
    entry2 = tk.Entry(window, width=20)
    entry2.pack()

    def change_state():
        global l
        number1 = entry1.get()
        number2 = entry2.get()
        l = []
        l.append(number1)
        l.append(number2)
        choose2()

    button = tk.Button(window, text='确认注册', command=change_state)
    button.pack()
    window.mainloop()


def choose1():
    m = 0
    number_and_keys = fop()
    for i in number_and_keys:
        if l == i:
            m = 1
            open1()
            break
    if m == 0:
        message1()


def choose2():
    number_and_keys = fop()
    for i in number_and_keys:
        if l == i:
            message2()
            break
        else:
            create(l)


def fget():
    point = 'https://www.dxsbb.com/news/5463.html'
    allinfor = []
    headers = {
        'Cookie': 'OCSSID=4df0bjva6j7ejussu8al3eqo03',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                      '(KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
    }
    r = requests.get(point, headers=headers)
    r.encoding = "gbk"
    soup = BeautifulSoup(r.text, "html.parser")
    trs = soup.find_all('tr')
    for tr in trs:
        tds = tr.find_all('td')
        if len(tds) == 0:
            continue
        oneinfor = []
        for td in tds:
            oneinfor.append(td.string)
        allinfor.append(oneinfor)
    dl = []
    for i in allinfor:
        if None in i:
            dl.append(i)
        else:
            i[3] = i[3][:-1]
    for t in dl:
        allinfor.remove(t)
    allinfor[0][3] = "星级"
    with open('2014020228-材料2002-章震豪.csv', 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        for row in allinfor[:631]:
            writer.writerow(row)
    lw(allinfor)


def lw(allinfor):
    root = tk.Tk()
    root.title('爬取数据显示')
    root.geometry("1000x800")
    for i in range(len(allinfor)):
        u = allinfor[i]
        l = tk.Label(root, text=u, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
        l.pack()


def j1():
    pl = 'students.db'
    file_path = r"2014020228-材料2002-章震豪.csv"
    with open(file_path, encoding='gbk') as f:
        data2 = np.loadtxt(f, str, delimiter=",", skiprows=0)
        data = []
    for line in data2:
        data.append(list(line))
    con_file = sqlite3.connect("students.db")

    try:
        con_file.execute('DROP TABLE pl');
        con_file.commit()
    except:
        pass

    con_mem = sqlite3.connect(":memory:")
    cr = con_file.cursor()
    cr.execute('CREATE TABLE pl(名次 text,学校名称 text ,总分 text,星级 text,办学层次 text)')
    std = []
    for i in data:
        std.append(tuple(i))
    cr.executemany('INSERT INTO pl VALUES (?, ?, ?, ?, ?)', std)
    con_file.commit()
    con_file.close()


def j2():
    pl = 'students.db'
    conn = sqlite3.connect(pl)
    cursor = conn.execute("SELECT * from pl")
    for it in cursor:
        for i in range(len(it)):
            print(it[i], end=" ")
        print()
    conn.close()


def j3():
    def tian():
        a = a2.get()
        b = b2.get()
        c = c2.get()
        d = d2.get()
        e = e2.get()
        a = str(a)
        b = str(b)
        c = str(c)
        d = str(d)
        e = str(e)
        m = (a, b, c, d, e)
        conn = sqlite3.connect('students.db')
        cursor = conn.cursor()
        cursor.execute("insert into pl values " + str(m) + ";")
        conn.commit()
        conn.close()

    def shan():
        a = a2.get()
        b = b2.get()
        c = c2.get()
        d = d2.get()
        e = e2.get()
        b = b.strip()
        conn = sqlite3.connect('students.db')
        cursor = conn.cursor()
        sql = "delete from pl where 学校名称=\'"+str(b)+"\';"
        cursor.execute(sql)
        conn.commit()
        conn.close()

    def gai():
        a = a2.get()
        b = b2.get()
        c = c2.get()
        d = d2.get()
        e = e2.get()
        a = str(a)
        b = str(b)
        c = str(c)
        d = str(d)
        e = str(e)
        try:
            
            conn = sqlite3.connect('students.db')
            cursor = conn.cursor()
            sql = "update pl set 名次=\'"+a+"\' 学校名称=\'"+b+"\' 总分=\'"+c+"\' 星级=\'"+d+"\' 办学层次=\'"+e+"\' where 学校名称=\'"+b+"\';"
            cursor.execute(sql)
            conn.commit()
            conn.close()
        except:
            window1 = tk.Tk()
            window1.geometry("600x350")
            window.title("请输入账号与密码")
            l4 = tk.Label(window1, text="未知错误", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
            l4.pack()
    root = tk.Tk()
    root.geometry('360x240')
    root.title('数据库处理')

    a1 = tk.Label(root, text='名次')
    a1.grid(row=0, column=0)
    a2 = tk.Entry(root)
    a2.grid(row=0, column=1)

    b1 = tk.Label(root, text='学校名称')
    b1.grid(row=1, column=0)
    b2 = tk.Entry(root)
    b2.grid(row=1, column=1)

    c1 = tk.Label(root, text='总分')
    c1.grid(row=2, column=0)
    c2 = tk.Entry(root)
    c2.grid(row=2, column=1)

    d1 = tk.Label(root, text='星级')
    d1.grid(row=3, column=0)
    d2 = tk.Entry(root)
    d2.grid(row=3, column=1)

    e1 = tk.Label(root, text='办学层次')
    e1.grid(row=4, column=0)
    e2 = tk.Entry(root)
    e2.grid(row=4, column=1)

    f1 = tk.Button(root, text='添加学校', command=tian)
    f1.grid(row=0, column=4)

    g1 = tk.Button(root, text='删除学校', command=shan)
    g1.grid(row=1, column=4)

    h1 = tk.Button(root, text='修改学校', command=gai)
    h1.grid(row=2, column=4)

    i1 = tk.Button(root, text='退出系统', command=exit)
    i1.grid(row=3, column=4)

    root.mainloop()


def fsql():
    pl = 'students.db'
    root = tk.Tk()
    root.title('数据库操作')
    root.geometry("600x350")
    l = tk.Label(root, text="数据库操作", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l.pack()
    mian_button1 = tk.Button(root, text="数据导入数据库", font=("NotoSansHans", 12), width=20, height=1, command=j1)
    mian_button1.pack()
    mian_button2 = tk.Button(root, text="查看全部数据库", font=("NotoSansHans", 12), width=20, height=1, command=j2)
    mian_button2.pack()
    mian_button2 = tk.Button(root, text="数据库增删改查", font=("NotoSansHans", 12), width=20, height=1, command=j3)
    mian_button2.pack()


def bing1():
    file_path = r"2014020228-材料2002-章震豪.csv"
    with open(file_path, encoding='gbk') as f:
        data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
    data = []
    for line in data2:
        data.append(list(line))
    dict = {}
    for i in data:
        dict[i[-1]] = dict.get(i[-1], 0) + 1

    p = ['world class ',

         'world famous high level',

         'world high level',

         'China first class',

         'China top',

         'regional first class',

         'regional high level',

         'regional famous']
    plt.pie(list(dict.values()), labels=p, autopct="%.1f%%")
    plt.title("University statistics")
    plt.show()


def bing2():
    file_path = r"2014020228-材料2002-章震豪.csv"
    with open(file_path, encoding='gbk') as f:
        data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
    data = []
    for line in data2:
        data.append(list(line))
    dict = {}
    for i in data:
        dict[i[-1]] = dict.get(i[-1], 0) + 1

    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    p = ["世界一流大学",
         "世界知名高水平大学",
         "世界高水平大学",
         "中国一流大学",
         "中国高水平大学",
         "区域一流大学",
         "区域高水平大学",
         "区域知名大学"]
    plt.pie(list(dict.values()), labels=p, autopct="%.1f%%")
    plt.title("大学等级分布")
    plt.show()


def shan():
    file_path = r"2014020228-材料2002-章震豪.csv"
    with open(file_path, encoding='gbk') as f:
        data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
    data = []
    for line in data2:
        data.append(list(line))
    dict = {}
    for i in data:
        dict[i[-1]] = dict.get(i[-1], 0) + 1
    ls = 0
    p = ["世界一流大学",
         "世界知名高水平大学",
         "世界高水平大学",
         "中国一流大学",
         "中国高水平大学",
         "区域一流大学",
         "区域高水平大学",
         "区域知名大学"]
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    matplotlib.rcParams['axes.unicode_minus'] = False
    for i in list(dict.values()):
        c1 = np.random.random(10)
        for t in range(i):
            x1 = np.random.rand(10)
            y1 = np.random.rand(10)
            plt.scatter(x1, y1, c=c1, label=p[ls], alpha=0.5)
        ls += 1
    plt.show()


def zhu():
    file_path = r"2014020228-材料2002-章震豪.csv"
    with open(file_path, encoding='gbk') as f:
        data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
    data = []
    for line in data2:
        data.append(list(line))
    dict = {}
    for i in data:
        dict[i[-1]] = dict.get(i[-1], 0) + 1
    c = list(dict.keys())
    n = list(dict.values())
    x = range(len(c))
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    plt.bar(x, n, width=0.3, color=["b", "r", "g", "y"] * 2)
    plt.xticks(x, c)
    plt.xlabel("大学等级")
    plt.ylabel("大学数量")
    plt.show()


def zhe():
    file_path = r"2014020228-材料2002-章震豪.csv"
    with open(file_path, encoding='gbk') as f:
        data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
    data = []
    for line in data2:
        data.append(list(line))
    dict = {}
    for i in data:
        dict[i[-1]] = dict.get(i[-1], 0) + 1
    x = list(dict.values())
    y = x
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
    plt.plot(x, y, label="大学数量折线图")
    plt.legend()
    plt.show()


def fcsv():
    def cs1():
        file_path = r"2014020228-材料2002-章震豪.csv"
        with open(file_path, encoding='gbk') as f:
            data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
        data = []
        for line in data2:
            data.append(list(line))
        student = []
        m1 = a22.get()
        m2 = b22.get()
        m3 = c22.get()
        m4 = d22.get()
        m10 = e22.get()
        student.append(m1)
        student.append(m2)
        student.append(m3)
        student.append(m4)
        student.append(m10)
        data.append(student)
        data = sorted(data, key=lambda i: int(i[0]))
        with open('2014020228-材料2002-章震豪.csv', 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            for row in data:
                writer.writerow(row)
        window = tk.Tk()
        window.geometry("600x350")
        window.title("完成提示")
        l = tk.Label(window, text="学校信息添加完毕", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
        l.pack()

    def cs2():
        file_path = r"2014020228-材料2002-章震豪.csv"
        with open(file_path, encoding='gbk') as f:
            data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
        data = []
        for line in data2:
            data.append(list(line))
        i1 = b22.get()
        for i in range(len(data)):
            if data[i][1] == i1:
                data.pop(i)
                break
        with open('2014020228-材料2002-章震豪.csv', 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            for row in data:
                writer.writerow(row)
        window = tk.Tk()
        window.geometry("600x350")
        window.title("完成提示")
        l = tk.Label(window, text="学校数据删除完毕", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
        l.pack()

    def cs3():
        file_path = r"2014020228-材料2002-章震豪.csv"
        with open(file_path, encoding='gbk') as f:
            data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
        data = []
        for line in data2:
            data.append(list(line))
        t = -1
        i2 = b22.get()
        for u in range(len(data)):
            if data[u][1] == i2:
                t = u
                break
        if t == -1:
            window = tk.Tk()
            window.geometry("600x350")
            window.title("完成提示")
            l = tk.Label(window, text="未找到该学校信息", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
            l.pack()
        else:
            m5 = a22.get()
            m6 = b22.get()
            m7 = c22.get()
            m8 = d22.get()
            m9 = e22.get()
            data[t][0] = m5
            data[t][1] = m6
            data[t][2] = m7
            data[t][3] = m8
            data[t][4] = m9
            data = sorted(data, key=lambda i: i[0])
            with open('2014020228-材料2002-章震豪.csv', 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                for row in data:
                    writer.writerow(row)
            window = tk.Tk()
            window.geometry("600x350")
            window.title("完成提示")
            l = tk.Label(window, text="学校信息修改完毕", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
            l.pack()

    root = tk.Tk()
    root.geometry('360x240')
    root.title('CSV处理')

    a11 = tk.Label(root, text='名次')
    a11.grid(row=0, column=0)
    a22 = tk.Entry(root)
    a22.grid(row=0, column=1)

    b11 = tk.Label(root, text='学校名称')
    b11.grid(row=1, column=0)
    b22 = tk.Entry(root)
    b22.grid(row=1, column=1)

    c11 = tk.Label(root, text='总分')
    c11.grid(row=2, column=0)
    c22 = tk.Entry(root)
    c22.grid(row=2, column=1)

    d11 = tk.Label(root, text='星级')
    d11.grid(row=3, column=0)
    d22 = tk.Entry(root)
    d22.grid(row=3, column=1)

    e11 = tk.Label(root, text='办学层次')
    e11.grid(row=4, column=0)
    e22 = tk.Entry(root)
    e22.grid(row=4, column=1)

    f11 = tk.Button(root, text='添加学校数据', command=cs1)
    f11.grid(row=0, column=4)

    g11 = tk.Button(root, text='删除学校数据', command=cs2)
    g11.grid(row=1, column=4)

    h11 = tk.Button(root, text='修改学校数据', command=cs3)
    h11.grid(row=2, column=4)

    i11 = tk.Button(root, text=' 退出系统 ', command=exit)
    i11.grid(row=3, column=4)


def fsee():
    root = tk.Tk()
    root.title('数据可视化')
    root.geometry("600x350")

    l = tk.Label(root, text="数据可视化", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l.pack()
    mian_button1 = tk.Button(root, text="Data visualization", font=("NotoSansHans", 12), width=20, height=1,
                             command=bing1)
    mian_button1.pack()

    mian_button2 = tk.Button(root, text="饼状图", font=("NotoSansHans", 12), width=20, height=1, command=bing2)
    mian_button2.pack()
    mian_button3 = tk.Button(root, text="散点图", font=("NotoSansHans", 12), width=20, height=1, command=shan)
    mian_button3.pack()
    mian_button4 = tk.Button(root, text="柱状图", font=("NotoSansHans", 12), width=20, height=1, command=zhu)
    mian_button4.pack()
    mian_button5 = tk.Button(root, text="折线图", font=("NotoSansHans", 12), width=20, height=1, command=zhe)
    mian_button5.pack()


def fpoint():
    load_window = tk.Tk()
    load_window.geometry("600x350")
    load_window.title("提示界面")

    l = tk.Label(load_window, text="权限未开启", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l.pack()

    mian_button1 = tk.Button(load_window, text="退出系统", font=("NotoSansHans", 12), width=20, height=1, command=exit)
    mian_button1.pack()


def ftj():

    def fcx():
        def c1():
            global lr
            lr = a22.get()
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            for i in data[1:]:
                i[0] = str(i[0])
                lm = 0
                p = []
                for i in data:
                    for c in i:
                        if str(lr) == c:
                            i = " ".join(i)
                            p.append(i)
                            lm += 1
                            break
            if lm == 0:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text="未找到对应学校", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
            else:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text='名次       学校名称        总分       星级           办学层次', bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
                for i in p:
                    l = tk.Label(load_window, text=i, bg="pink",font=("NotoSansHans", 12), width=200, height=2)
                    l.pack()

        def c2():
            global lr
            lr = a22.get()
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            for i in data[1:]:
                i[0] = str(i[0])
                lm = 0
                p = []
                for i in data:
                    for c in i:
                        if str(lr) == c:
                            i = " ".join(i)
                            p.append(i)
                            lm += 1
                            break
            if lm == 0:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text="未找到对应学校", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
            else:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text='名次       学校名称        总分       星级           办学层次', bg="pink",
                             font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
                for i in p:
                    l = tk.Label(load_window, text=i, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                    l.pack()
            return lr

        def c3():
            global lr
            lr = a22.get()
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            for i in data[1:]:
                i[0] = str(i[0])
                lm = 0
                p = []
                for i in data:
                    for c in i:
                        if str(lr) == c:
                            i = " ".join(i)
                            p.append(i)
                            lm += 1
                            break
            if lm == 0:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text="未找到对应学校", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
            else:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text='名次       学校名称        总分       星级           办学层次', bg="pink",
                             font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
                for i in p:
                    l = tk.Label(load_window, text=i, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                    l.pack()
            return lr

        def c4():
            global lr
            lr = a22.get()
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            for i in data[1:]:
                i[0] = str(i[0])
                lm = 0
                p = []
                for i in data:
                    for c in i:
                        if str(lr) == c:
                            i = " ".join(i)
                            p.append(i)
                            lm += 1
                            break
            if lm == 0:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text="未找到对应学校", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
            else:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text='名次       学校名称        总分       星级           办学层次', bg="pink",
                             font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
                for i in p:
                    l = tk.Label(load_window, text=i, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                    l.pack()
            return lr

        def c5():
            global lr
            lr = a22.get()
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            for i in data[1:]:
                i[0] = str(i[0])
                lm = 0
                p = []
                for i in data:
                    for c in i:
                        if str(lr) == c:
                            i = " ".join(i)
                            p.append(i)
                            lm += 1
                            break
            if lm == 0:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text="未找到对应学校", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
            else:
                load_window = tk.Tk()
                load_window.geometry("600x350")
                load_window.title("提示界面")

                l = tk.Label(load_window, text='名次       学校名称        总分       星级           办学层次', bg="pink",
                             font=("NotoSansHans", 12), width=200, height=2)
                l.pack()
                for i in p:
                    l = tk.Label(load_window, text=i, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                    l.pack()
            return lr


        root = tk.Tk()
        root.geometry('360x240')
        root.title('模糊查询功能')

        a11 = tk.Label(root, text='名次')
        a11.grid(row=0, column=0)
        a22 = tk.Entry(root)
        a22.grid(row=0, column=1)

        b11 = tk.Label(root, text='学校名称')
        b11.grid(row=1, column=0)
        b22 = tk.Entry(root)
        b22.grid(row=1, column=1)

        c11 = tk.Label(root, text='总分')
        c11.grid(row=2, column=0)
        c22 = tk.Entry(root)
        c22.grid(row=2, column=1)

        d11 = tk.Label(root, text='星级')
        d11.grid(row=3, column=0)
        d22 = tk.Entry(root)
        d22.grid(row=3, column=1)

        e11 = tk.Label(root, text='办学层次')
        e11.grid(row=4, column=0)
        e22 = tk.Entry(root)
        e22.grid(row=4, column=1)

        f11 = tk.Button(root, text='根据名次查询', command=c1)
        f11.grid(row=0, column=4)

        f11 = tk.Button(root, text='根据名称查询', command=c2)
        f11.grid(row=1, column=4)

        f11 = tk.Button(root, text='根据总分查询', command=c3)
        f11.grid(row=2, column=4)

        f11 = tk.Button(root, text='根据星级查询', command=c4)
        f11.grid(row=3, column=4)

        f11 = tk.Button(root, text='根据办学层次查询', command=c5)
        f11.grid(row=4,column=4)

        i11 = tk.Button(root, text='退出系统', command=exit)
        i11.grid(row=5, column=4)

        
    
    def tjf():
        def tj1():
            load_window4 = tk.Tk()
            load_window4.geometry("600x350")
            load_window4.title("信息统计功能")
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            dict = {}
            for i in data:
                dict[i[-1]] = dict.get(i[-1], 0) + 1
            for i, j in dict.items():
                lu = str(i) + str(j)
                l = tk.Label(load_window4, text=lu, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()

        def tj2():
            load_window7 = tk.Tk()
            load_window7.geometry("600x350")
            load_window7.title("信息统计功能")
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            dict = {}
            for i in data:
                dict[i[-2]] = dict.get(i[-2], 0) + 1
            for i, j in dict.items():
                lu = str(i)+"星级大学：" + str(j)+"所"
                l = tk.Label(load_window7, text=lu, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()

        def tj3():
            load_window6 = tk.Tk()
            load_window6.geometry("600x350")
            load_window6.title("信息统计功能")
            file_path = r"2014020228-材料2002-章震豪.csv"
            with open(file_path, encoding='gbk') as f:
                data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
            data = []
            for line in data2:
                data.append(list(line))
            dict = {}
            for i in data:
                dict[i[-3]] = dict.get(i[-3], 0) + 1
            for i, j in dict.items():
                lu = str(i)+"分：" + str(j)+"所"
                l = tk.Label(load_window6, text=lu, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
                l.pack()



        load_window3 = tk.Tk()
        load_window3.geometry("600x350")
        load_window3.title("信息统计功能")

        mian_button1 = tk.Button(load_window3, text="根据办学层次统计", font=("NotoSansHans", 12), width=20, height=1, command=tj1)
        mian_button1.pack()
        mian_button1 = tk.Button(load_window3, text="根据星级统计", font=("NotoSansHans", 12), width=20, height=1, command=tj2)
        mian_button1.pack()
        mian_button1 = tk.Button(load_window3, text="根据总分统计", font=("NotoSansHans", 12), width=20, height=1, command=tj3)
        mian_button1.pack()
        mian_button1 = tk.Button(load_window3, text="退出系统", font=("NotoSansHans", 12), width=20, height=1, command=exit)
        mian_button1.pack()

        file_path = r"2014020228-材料2002-章震豪.csv"
        with open(file_path, encoding = 'gbk') as f:
            data2 = np.loadtxt(f, str, delimiter=",", skiprows=1)
        data = []
        for line in data2:
            data.append(list(line))
        dict = {}
        for i in data:
            dict[i[-1]] = dict.get(i[-1], 0) + 1
        for i, j in dict.items():
            lu = str(i)+str(j)
            l = tk.Label(load_window2, text=lu, bg="pink", font=("NotoSansHans", 12), width=200, height=2)
            l.pack()

    load_window = tk.Tk()
    load_window.geometry("600x350")
    load_window.title("统计功能")

    l = tk.Label(load_window, text="统计功能", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
    l.pack()

    mian_button1 = tk.Button(load_window, text="模糊查询功能", font=("NotoSansHans", 12), width=20, height=1, command=fcx)
    mian_button1.pack()
    mian_button1 = tk.Button(load_window, text="信息统计功能", font=("NotoSansHans", 12), width=20, height=1, command=tjf)
    mian_button1.pack()
    mian_button1 = tk.Button(load_window, text="退出系统", font=("NotoSansHans", 12), width=20, height=1, command=exit)
    mian_button1.pack()


def mainmin():
    def fgui():
        load_window = tk.Tk()
        load_window.geometry("600x350")
        load_window.title("数据系统用户界面")

        l = tk.Label(load_window, text="数据处理系统", bg="pink", font=("NotoSansHans", 12), width=200, height=2)
        l.pack()
        l2 = tk.Label(load_window, text="开发：UPC章震豪", bg="blue", font=("NotoSansHans", 12), width=200, height=2)
        l2.pack()
        l3 = tk.Label(load_window, text="以下是功能列表", bg="red", font=("NotoSansHans", 12), width=200, height=2)
        l3.pack()

        mian_button1 = tk.Button(load_window, text="爬取数据", font=("NotoSansHans", 12), width=20, height=1, command=f1)
        mian_button1.pack()
        mian_button2 = tk.Button(load_window, text="CSV数据处理", font=("NotoSansHans", 12), width=20, height=1, command=f3)
        mian_button2.pack()
        mian_button3 = tk.Button(load_window, text="数据统计", font=("NotoSansHans", 12), width=20, height=1, command=f4)
        mian_button3.pack()
        mian_button4 = tk.Button(load_window, text="数据可视化", font=("NotoSansHans", 12), width=20, height=1, command=f5)
        mian_button4.pack()
        mian_button5 = tk.Button(load_window, text="数据库操作", font=("NotoSansHans", 12), width=20, height=1, command=f2)
        mian_button5.pack()
        mian_button6 = tk.Button(load_window, text="退出系统", font=("NotoSansHans", 12), width=20, height=1, command=exit)
        mian_button6.pack()

    if lex == 1:
        def f1():
            fget()

        def f2():
            fsql()

        def f3():
            fcsv()

        def f4():
            ftj()

        def f5():
            fsee()

        fgui()

    else:
        fpoint()


# 运行主函数
main()
